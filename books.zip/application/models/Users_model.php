<?php

class Users_model extends CI_Model {

	// method untuk membaca data profile user
	public function getUserProfile($username = false){
		$query = $this->db->get_where('users', array('username' => $username));
		return $query->row_array();
	}
	public function showusers(){
		$query = $this->db->get('users');
		return $query->result_array();
	}
	public function deluser($username){
		$this->db->delete('users', array('username'=>$username));
	}
	public function insertusers($username, $fullname, $password, $role){
		$data=array(
			"username"=>$username,
			"fullname"=>$fullname,
			"password"=>$password,
			"role"=>$role

			);
		$query=$this->db->insert('users',$data);
	}
	public function getusers(){
		$query=$this->db->get('users');
		return $query->result_array();
	}
	public function updateUser($username, $fullname, $password, $role){
		$data = array(
					"fullname" => $fullname,
					"role" => $role,
					"password" => $password
		);
		$this->db->update('users', $data, 'username = "' . $username. '"');
	}
	public function updatekat($idkategori, $kategori){
		$data = array(
					"idkategori" => $idkategori,
					"kategori" => $kategori
		);
		$this->db->where('idkategori', $idkategori);
		$this->db->update('kategori', $data);
	}
}
?>
