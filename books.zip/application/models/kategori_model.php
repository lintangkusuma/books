<?php

class kategori_model extends CI_Model {

	// method untuk menampilkan data buku
	public function showkategori($id = false){
		// membaca semua data kategori buku dari tabel 'kategori'
		if ($id == false){
			$query = $this->db->get('kategori');
			return $query->result_array();
		} else {
			// membaca data kategori buku berdasarkan id
			$query = $this->db->get_where('kategori', array("idkategori" => $id));
			return $query->row_array();
		}
	}

	// method untuk hapus data buku berdasarkan id
	public function delkategori($id){
		$this->db->delete('kategori', array("idkategori" => $id));
	}


	// method untuk insert data buku ke tabel 'kategori'
	public function insertkategori($kategori){
		$data = array(
					"kategori" => $kategori,
					
		);
		$query = $this->db->insert('kategori', $data);
	}

	// method untuk membaca data kategori buku dari tabel 'kategori'
	public function getKategori(){
		$query = $this->db->get('kategori');
		return $query->result_array();
	}

	// method untuk menghitung jumlah buku berdasarkan idkategori
	public function countByCat($idkategori){
		$query = $this->db->query("SELECT count(*) as jum FROM books WHERE idkategori = '$idkategori'");
		return $query->row()->jum;
	}
	public function updateCat($idkategori, $kategori){
		$data = array(
					"idkategori" => $idkategori,
					"kategori" => $kategori
		);
		$this->db->where('idkategori', $idkategori);
		$this->db->update('kategori', $data);
	}

}
?>