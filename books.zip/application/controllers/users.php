<?php
class users extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('users_model');
		// cek keberadaan session 'username'	
		if (!isset($_SESSION['username'])){
			// jika session 'username' blm ada, maka arahkan ke kontroller 'login'
			redirect('login');
		}
	}


	// method hapus data buku berdasarkan id
	public function delete($username){
		$this->Users_model->deluser($username);
		// arahkan ke method 'books' di kontroller 'dashboard'
		redirect('dashboard/users');
	}

	// method untuk tambah data buku
	public function insert(){
		// target direktori fileupload
	$username=$_POST['username'];
	$fullname=$_POST['fullname'];
	$password=$_POST['password'];
	$role=$_POST['role'];
	
	$this->users_model->insertusers($username, $fullname, $password, $role);

	redirect('dashboard/users');
	}

	// method untuk edit data buku berdasarkan id
	public function edit($username){

        $data['view_user'] = $this->users_model->getUserProfile($username);

        $data['fullname'] = $_SESSION['fullname'];

        if (empty($data['view_user'])){
            show_404();
        }

        $data['username'] = $data['view_user']['username'];
        $data['fullname'] = $data['view_user']['fullname'];
        $data['role'] = $data['view_user']['role'];
        $data['password'] = $data['view_user']['password'];

        $this->load->view('dashboard/header', $data);
        $this->load->view('dashboard/editUser', $data);
        $this->load->view('dashboard/footer');
    }

    public function update(){

		$username = $_POST['username'];
		$fullname = $_POST['fullname'];
		$role = $_POST['role'];
		$password = $_POST['password'];

		// panggil method insertBook() di model 'book_model' untuk menjalankan query insert
		$this->users_model->updateUser($username, $fullname, $password, $role);

		// arahkan ke method 'books' di kontroller 'dashboard'
		redirect('dashboard/users');
	}

	// method untuk mencari data buku berdasarkan 'key'

}
?>