<main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">


  <form action="<?php echo site_url('dashboard/addkat'); ?>">
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Kategori Buku</h1> <div class="panel-heading">
        <button class="btn btn-primary pull-right" data-toggle="modal" data-target="#myModal">Tambah</button></div>
      </div>
</form>

      <div class="table-responsive">
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th>ID KATEGORI</th>
              <th>KATEGORI</th>
              <th>ACTION</th>
            </tr>
          </thead>
          <tbody>
          <?php 
            // menampilkan data buku
            foreach ($kategori as $kategori_item): 

            ?>
            <tr>
              <td><?php echo $kategori_item['idkategori']?></td>
              <td><?php echo $kategori_item['kategori']?></td>
              
              <td><?php echo anchor('kategori/edit/'.$kategori_item['idkategori'], 'Edit') ?>| <?php echo anchor('kategori/delete/'.$kategori_item['idkategori'], 'Del', 'Hapus Buku'); ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </main>
  