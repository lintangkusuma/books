<!DOCTYPE html>
<!-- saved from url=(0053)https://getbootstrap.com/docs/4.3/examples/dashboard/ -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Jekyll v3.8.5">
    <title>B O O K </title>

    <link rel="canonical" href="https://getbootstrap.com/docs/4.3/examples/dashboard/">

    <!-- Bootstrap core CSS -->
    <!-- arahkan url ke direktori 'assets' -->
<link href="<?php echo base_url();?>assets/bootstrap.min.css" rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">


    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>
    <!-- Custom styles for this template -->
    <!-- arahkan url ke direktori 'assets' -->
    <link href="<?php echo base_url();?>assets/dashboard.css" rel="stylesheet">
  <style type="text/css">/* Chart.js */
@-webkit-keyframes chartjs-render-animation{from{opacity:0.99}to{opacity:1}}@keyframes chartjs-render-animation{from{opacity:0.99}to{opacity:1}}.chartjs-render-monitor{-webkit-animation:chartjs-render-animation 0.001s;animation:chartjs-render-animation 0.001s;}</style></head>
  <body>
    <nav class="navbar navbar-dark fixed-top bg-dark flex-md-nowrap p-0 shadow">
  <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="https://getbootstrap.com/docs/4.3/examples/dashboard/#">B O O K</a>

  <!-- tampilkan fullname dari user yang sedang login -->
  <div class="w-100" style="margin-left: 25px; color: white;">Welcome, <?php echo $fullname; ?></div>

  <ul class="navbar-nav px-3">
    <li class="nav-item text-nowrap">
      <!-- arahkan link ke kontroller 'dashboard/logout' -->
      <a class="nav-link" href="<?php echo site_url('dashboard/logout');?>">Sign out</a>
    </li>
  </ul>
</nav>

<div class="container-fluid">
  <div class="row">
    <nav class="col-md-2 d-none d-md-block bg-light sidebar">
      <div class="sidebar-sticky">
        <ul class="nav flex-column">
          <li class="nav-item">
            <!-- arahkan link ke kontroller 'dashboard/index' -->
            <a class="nav-link" href="<?php echo site_url('dashboard'); ?>">
              <svg style="width:24px;height:24px" viewBox="0 0 24 24">
    <path fill="#000000" d="M9,19V13H11L13,13H15V19H18V10.91L12,4.91L6,10.91V19H9M12,2.09L21.91,12H20V21H13V15H11V21H4V12H2.09L12,2.09Z"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
              Dashboard
            </a>
          </li>
          <?php
          if ($_SESSION['role'] == 'admin'){
            ?>
          <li class="nav-item">
            <!-- arahkan link ke kontroller 'dashboard/add' -->
            <a class="nav-link" href="<?php echo site_url('dashboard/add'); ?>">
              <svg style="width:24px;height:24px" viewBox="0 0 24 24">
    <path fill="#000000" d="M3,3A2,2 0 0,0 1,5V19A2,2 0 0,0 3,21H21A2,2 0 0,0 23,19V5A2,2 0 0,0 21,3H3M3,5H13V9H21V19H3V5M10,10V13H7V15H10V18H12V15H15V13H12V10H10Z"></path><polyline points="13 2 13 9 20 9"></polyline></svg>
              Tambah Data Buku
            </a>
          </li>
           <?php
          }
            ?>
          <li class="nav-item">
            <!-- arahkan link ke kontroller 'dashboard/books' -->
            <a class="nav-link" href="<?php echo site_url('dashboard/books'); ?>">
              <svg style="width:24px;height:24px" viewBox="0 0 24 24">
    <path fill="#000000" d="M21,4H3A2,2 0 0,0 1,6V19A2,2 0 0,0 3,21H21A2,2 0 0,0 23,19V6A2,2 0 0,0 21,4M3,19V6H11V19H3M21,19H13V6H21V19M14,9.5H20V11H14V9.5M14,12H20V13.5H14V12M14,14.5H20V16H14V14.5Z"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>
              Data Buku
            </a>
          </li>
          <?php
          if ($_SESSION['role'] == 'admin'){
            ?>
           <li class="nav-item">
            <!-- arahkan link ke kontroller 'dashboard/books' -->
            <a class="nav-link" href="<?php echo site_url('dashboard/kategori'); ?>">
              <svg style="width:24px;height:24px" viewBox="0 0 24 24">
    <path fill="#000000" d="M7,5H21V7H7V5M7,13V11H21V13H7M4,4.5A1.5,1.5 0 0,1 5.5,6A1.5,1.5 0 0,1 4,7.5A1.5,1.5 0 0,1 2.5,6A1.5,1.5 0 0,1 4,4.5M4,10.5A1.5,1.5 0 0,1 5.5,12A1.5,1.5 0 0,1 4,13.5A1.5,1.5 0 0,1 2.5,12A1.5,1.5 0 0,1 4,10.5M7,19V17H21V19H7M4,16.5A1.5,1.5 0 0,1 5.5,18A1.5,1.5 0 0,1 4,19.5A1.5,1.5 0 0,1 2.5,18A1.5,1.5 0 0,1 4,16.5Z"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>
              Kategori 
            </a>
          </li>
          <?php
          }
            ?>
            <?php
          if ($_SESSION['role'] == 'admin'){
            ?>
           <li class="nav-item">
            <!-- arahkan link ke kontroller 'dashboard/books' -->
            <a class="nav-link" href="<?php echo site_url('dashboard/users'); ?>">
              <svg style="width:24px;height:24px" viewBox="0 0 24 24">
    <path fill="#000000" d="M19,19H5V5H19M19,3H5A2,2 0 0,0 3,5V19A2,2 0 0,0 5,21H19A2,2 0 0,0 21,19V5C21,3.89 20.1,3 19,3M16.5,16.25C16.5,14.75 13.5,14 12,14C10.5,14 7.5,14.75 7.5,16.25V17H16.5M12,12.25A2.25,2.25 0 0,0 14.25,10A2.25,2.25 0 0,0 12,7.75A2.25,2.25 0 0,0 9.75,10A2.25,2.25 0 0,0 12,12.25Z"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>
              User
            </a>
          </li>
          <?php
          }
            ?>
        </ul>

      </div>
    </nav>