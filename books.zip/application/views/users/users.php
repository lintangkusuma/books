<main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">


  
      <form action="<?php echo site_url('dashboard/addusers'); ?>">
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">User</h1> <div class="panel-heading">
        <button class="btn btn-primary pull-right" data-toggle="modal" data-target="#myModal">Tambah</button></div>
      </div>
</form>

    
      <div class="table-responsive">
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th>Username</th>
              <th>Password</th>
              <th>Nama Lengkap</th>
              <th>Role</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
          <?php 
            // menampilkan data buku
            foreach ($users as $user_item): 

            ?>
            <tr>
              <td><?php echo $user_item['username']?></td>
              <td><?php echo $user_item['password']?></td>
              <td><?php echo $user_item['fullname']?></td>
              <td><?php echo $user_item['role']?></td>
             

              <td>View |<?php echo anchor('users/edit/'.$user_item['username'], 'Edit') ?>| <?php echo anchor('users/delete/'.$user_item['username'], 'Del', 'Hapus Buku'); ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </main>
  